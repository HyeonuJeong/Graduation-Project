package kr.smarket.application.Domain.Enum;

public enum Region {
    SEOUL,
    INCHEON,
    DAEJEON,
    DAEGU,
    GWANGJU,
    BOOSAN,
    ULSAN,
    GYEONGGI,
    GANGWON,
    CHUNGBUK,
    CHUNGNAM,
    GYEONGBUK,
    GYEONGNAM,
    JEONBUK,
    JEONNAM,
    JEJU,
    SEJONG,
    NONE
}
