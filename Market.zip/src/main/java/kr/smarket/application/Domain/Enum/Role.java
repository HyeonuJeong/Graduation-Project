package kr.smarket.application.Domain.Enum;

public enum Role {
    GUSET,
    USER,
    ADMIN
}
