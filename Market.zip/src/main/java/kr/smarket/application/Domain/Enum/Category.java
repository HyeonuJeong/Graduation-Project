package kr.smarket.application.Domain.Enum;

public enum Category {
    NONG_SAN_MUL,
    SU_SAN_MUL,
    CHEONG_GWA_MUL,
    JEONG_YUK_JEOM,
    JAP_HWA_JEOM,
    NONE
}
