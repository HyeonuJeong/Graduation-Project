package kr.smarket.application.Domain.Enum;

public enum UserType {
    BUSINESS,
    CLIENT
}
