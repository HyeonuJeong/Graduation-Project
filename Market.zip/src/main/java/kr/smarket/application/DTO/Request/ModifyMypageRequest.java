package kr.smarket.application.DTO.Request;

import lombok.Data;

@Data
public class ModifyMypageRequest {
    String userName;
    String phoneNumber;
}
